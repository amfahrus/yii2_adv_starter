<?php

/* @var $this yii\web\View */

$this->title = Yii::$app->name;
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Dashboard!</h1>

        <p class="lead">Under Cosntruction</p>
    </div>

    <div class="body-content">


    </div>
</div>
