<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\models\UserdataInternal */

$this->title = 'Create Userdata Internal';
$this->params['breadcrumbs'][] = ['label' => 'Userdata Internals', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="userdata-internal-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
